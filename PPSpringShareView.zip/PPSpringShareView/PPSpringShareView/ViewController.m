//
//  ViewController.m
//  PPSpringShareView
//
//  Created by macfai on 16/2/23.
//  Copyright © 2016年 pengpeng. All rights reserved.
//

#import "ViewController.h"
#import "ShareView.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    // Do any additional setup after loading the view, typically from a nib.
}
- (IBAction)shareBtnClicked:(id)sender {
    
    NSMutableArray *titleArray = [NSMutableArray arrayWithObjects:@"微信",@"朋友圈",@"QQ",@"空间",@"微博", nil];
    NSMutableArray *picArray = [NSMutableArray arrayWithObjects:@"1",@"2",@"3",@"4",@"5", nil];
    
    ShareView *share = [[ShareView alloc]initWithTitleArray:titleArray picArray:picArray];
    [share showShareView];
    [share currentIndexWasSelected:^(NSInteger index) {
        NSLog(@"%ld",(long)index);
    }];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
